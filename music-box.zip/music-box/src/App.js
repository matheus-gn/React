function App() {
  return (
    
        <p>
          Pega o React kkkkkkkk
        </p>
        
  );
}

export default App;
